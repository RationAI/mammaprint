"""Run exactly one reviewed CPU explanation and publish its report on its new run."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import tempfile
import time


def verify_saved_test_metrics(job: dict, slide_keys_path: Path) -> dict:
    """Compare current predictions with the published recovery evaluation."""
    import math
    import pandas as pd
    import torch
    from ml.metrics.summary import binary_logit_summary, regression_summary

    table = pd.read_csv(slide_keys_path)
    if job["label_mode"] == "index":
        actual = regression_summary(
            torch.tensor(table.prediction_mammaprint_index.to_numpy()),
            torch.tensor(table.mammaprint_index.to_numpy()),
        )
    else:
        actual = binary_logit_summary(
            torch.tensor(table.prediction_luminal_a_logit.to_numpy()),
            torch.tensor(table.class_label.to_numpy()),
        )
    comparisons = {}
    for key, expected in job["expected_test_metrics"].items():
        metric = key.removeprefix("test/")
        if metric in actual:
            measured = actual[metric]
            comparisons[key] = {
                "expected": expected,
                "actual": measured,
                "matches": math.isclose(measured, expected, abs_tol=1e-5, rel_tol=1e-5),
            }
    if not comparisons or any(not c["matches"] for c in comparisons.values()):
        raise RuntimeError(f"Saved test evaluation did not reproduce: {comparisons}")
    return comparisons


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--job", required=True)
    args = parser.parse_args()
    plan = json.loads(Path(__file__).with_name("plan.json").read_text())
    job = next(j for j in plan["jobs"] if j["key"] == args.job)
    resources = job["resources"]
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    os.environ["NVIDIA_VISIBLE_DEVICES"] = "void"
    for name in (
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = str(resources["cpu"])
    scratch_root = Path(plan["scratch_root"])
    scratch_root.mkdir(parents=True, exist_ok=True)
    free_gib = shutil.disk_usage(scratch_root).free / 2**30
    if free_gib < resources["shared_scratch_budget_gib"]:
        raise RuntimeError(f"Only {free_gib:.1f} GiB free in secured scratch storage.")
    scratch = scratch_root / job["job_name"]
    scratch.mkdir()  # Refuse reuse of a previous run's working files.
    temporary = scratch / "tmp"
    temporary.mkdir()
    os.environ["TMPDIR"] = str(temporary)
    tempfile.tempdir = str(temporary)
    os.environ["MLFLOW_TRACKING_URI"] = plan["tracking_uri"]
    os.environ["MLFLOW_UI_URI"] = plan["lookup_uri"]
    os.environ["XOPAT_UI_URI"] = plan["xopat_ui_uri"]

    import torch
    from mlflow import MlflowClient
    from ml.explain import main as explain_main

    torch.set_num_threads(resources["cpu"])
    torch.set_num_interop_threads(1)
    if torch.cuda.is_available():
        raise RuntimeError("This prepared submission must not expose a CUDA GPU.")
    client = MlflowClient(tracking_uri=plan["tracking_uri"])
    previous = client.search_runs(
        ["3"], f"attributes.run_name = '{job['run_name']}'", max_results=1
    )
    if previous:
        raise RuntimeError(
            f"An explanation run already exists: {previous[0].info.run_id}"
        )
    result_file = scratch / "result.json"
    argv = [
        "--checkpoint-uri",
        job["checkpoint_uri"],
        "--split",
        plan["split"],
        "--device",
        "cpu",
        "--resolved-source-config",
        "--tracking-uri",
        plan["tracking_uri"],
        "--mlflow-ui-uri",
        plan["lookup_uri"],
        "--xopat-ui-uri",
        plan["xopat_ui_uri"],
        "--run-name",
        job["run_name"],
        "--result-json",
        str(result_file),
        "--expected-checkpoint-sha256",
        job["checkpoint_sha256"],
        "--expected-source-config-sha256",
        job["source_config_sha256"],
    ]
    for override in job["explain_overrides"]:
        argv.extend(("--override", override))
    started = time.monotonic()
    if explain_main(argv) != 0:
        raise RuntimeError("Explanation command failed.")
    result = json.loads(result_file.read_text())
    if result["source_run_id"] != job["source_run_id"]:
        raise RuntimeError("Completed run has an unexpected source model.")
    run_id = result["run_id"]
    counts_ok = (
        result["failed_slides"] == 0
        and result["successful_slides"] == plan["expected_slides"]
        and result["rendered_slides"] == plan["expected_slides"]
    )
    if not counts_ok:
        client.set_tag(run_id, "prepared_submission.status", "needs_review")
        raise RuntimeError(f"Expected all {plan['expected_slides']} slides: {result}")
    manifest_path = Path(
        client.download_artifacts(run_id, "explanations/manifest.json", str(scratch))
    )
    manifest = json.loads(manifest_path.read_text())
    expected_methods = {"leave_one_out", "single"}
    if job["aggregator"] == "AttentionMIL":
        expected_methods.add("attention")
    if set(manifest["methods"]) != expected_methods:
        raise RuntimeError("Unexpected explanation methods in the completed run.")
    if manifest["baseline"]["skipped_slides"]:
        client.set_tag(run_id, "prepared_submission.status", "needs_review")
        raise RuntimeError(
            "Training baseline skipped slides; review before publishing."
        )
    slide_keys = Path(
        client.download_artifacts(run_id, "explanations/slide_keys.csv", str(scratch))
    )
    try:
        evaluation_comparison = verify_saved_test_metrics(job, slide_keys)
    except Exception:
        client.set_tag(run_id, "prepared_submission.status", "needs_review")
        raise
    subprocess.run(
        [
            sys.executable,
            "-m",
            "ml.explain_report",
            "--run-id",
            run_id,
            "--tracking-uri",
            plan["tracking_uri"],
            "--mlflow-ui-uri",
            plan["lookup_uri"],
            "--xopat-ui-uri",
            plan["xopat_ui_uri"],
            "--output-dir",
            str(scratch / "published-report"),
        ],
        check=True,
    )
    notes = {
        "prepared_job": job["key"],
        "source_run_id": job["source_run_id"],
        "resources": resources,
        "device": "cpu",
        "all_slides_rendered": True,
        "wall_seconds": time.monotonic() - started,
        "process_peak_rss_gib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        / (2**20 if sys.platform != "darwin" else 2**30),
        "display": plan["display"],
        "actual_visualization_scales": manifest["visualization_scales"],
        "reproduced_saved_test_metrics": evaluation_comparison,
        "interpretation": [
            "Brightness scales are independent by model, method and target; not comparable effect sizes.",
            "Tile removal: full-slide raw output minus output without a tile.",
            "Single: standalone raw prediction, not a change in the full-slide prediction.",
            "Attention: nonnegative raw weights summing to one; uniform weight is 1/tile_count.",
            "The viewer cutoff is 1% of the normalized display scale, not a significance cutoff.",
            "GeoJSON contains each slide's top and bottom 5%; these need not be large effects.",
        ],
    }
    notes_file = scratch / "submission-validation.json"
    notes_file.write_text(json.dumps(notes, indent=2) + "\n")
    client.log_artifact(run_id, str(notes_file), artifact_path="report")
    client.log_metric(
        run_id, "resources/process_peak_rss_gib", notes["process_peak_rss_gib"]
    )
    client.log_metric(run_id, "resources/wall_seconds", notes["wall_seconds"])
    client.set_tag(run_id, "prepared_submission.status", "complete")
    client.set_tag(run_id, "prepared_submission.gpu", "none")
    print(f"COMPLETED_EXPLANATION_RUN_ID={run_id}", flush=True)
    shutil.rmtree(temporary)  # Only this successful job's embedding/cache directory.


if __name__ == "__main__":
    main()
